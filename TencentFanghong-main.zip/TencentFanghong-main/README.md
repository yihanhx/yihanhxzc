# qq_fanghong

## 引言

因为`github.io`自身就是自带QQ、微信防红的域名，所以是用来做防红接口的不错材料。

## 使用方法

1.fork本仓库
2.生成Github pages（自行百度）
3.然后即可使用
